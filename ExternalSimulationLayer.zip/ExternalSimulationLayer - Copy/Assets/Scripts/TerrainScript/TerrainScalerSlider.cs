using UnityEngine;
using UnityEngine.UI;

public class TerrainScalerSlider : MonoBehaviour
{
    [Tooltip("Reference to the UI Slider for scaling the terrain.")]
    [SerializeField] private Slider terrainScalerSlider; // Reference to the UI Slider

    private Vector3 initialTerrainScale; // Store the initial scale of the terrain

    private void Start()
    {
        if (terrainScalerSlider == null)
        {
            Debug.LogError("TerrainScalerSlider: Slider reference is not set.");
            return;
        }

        InitializeTerrainScale();
        terrainScalerSlider.onValueChanged.AddListener(UpdateTerrainScale);
    }

    /// <summary>
    /// Initializes the terrain's scale and sets the slider to its default value.
    /// </summary>
    private void InitializeTerrainScale()
    {
        initialTerrainScale = transform.localScale;
        terrainScalerSlider.value = 1; // Default slider value
        UpdateTerrainScale(terrainScalerSlider.value); // Ensure terrain is correctly scaled initially
    }

    /// <summary>
    /// Updates the terrain's scale based on the slider value.
    /// </summary>
    /// <param name="scaleFactor">The current value of the slider.</param>
    private void UpdateTerrainScale(float scaleFactor)
    {
        transform.localScale = initialTerrainScale * scaleFactor;
    }

    private void OnDestroy()
    {
        // Remove the listener to avoid memory leaks
        if (terrainScalerSlider != null)
        {
            terrainScalerSlider.onValueChanged.RemoveListener(UpdateTerrainScale);
        }
    }
}
