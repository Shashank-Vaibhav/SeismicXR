using UnityEngine;
using UnityEngine.Video;

public class MaterialManager : MonoBehaviour
{
    [SerializeField] private Renderer terrainRenderer; // Reference to the terrain's renderer
    [SerializeField] private VideoPlayer textureVideo; // Reference to the VideoPlayer for texture

    [Tooltip("Assign 6 materials corresponding to the 6 buttons.")]
    [SerializeField] private Material[] materials; // Array of 6 materials

    [Tooltip("Assign 6 video clips corresponding to the 6 buttons.")]
    [SerializeField] private VideoClip[] videoClips; // Array of 6 video clips

    private void Awake()
    {
        // Validate that arrays are correctly assigned and have the right length
        if (materials.Length != 6 || videoClips.Length != 6)
        {
            Debug.LogError("MaterialManager: Please assign exactly 6 materials and 6 video clips in the Inspector.");
        }
    }

    // Function for Button 1
    public void SetMaterialAndVideo1()
    {
        SetMaterialAndVideo(0);
    }

    // Function for Button 2
    public void SetMaterialAndVideo2()
    {
        SetMaterialAndVideo(1);
    }

    // Function for Button 3
    public void SetMaterialAndVideo3()
    {
        SetMaterialAndVideo(2);
    }

    // Function for Button 4
    public void SetMaterialAndVideo4()
    {
        SetMaterialAndVideo(3);
    }

    // Function for Button 5
    public void SetMaterialAndVideo5()
    {
        SetMaterialAndVideo(4);
    }

    // Function for Button 6
    public void SetMaterialAndVideo6()
    {
        SetMaterialAndVideo(5);
    }

    /// <summary>
    /// Sets the material and video for the given index.
    /// </summary>
    /// <param name="index">The index of the material and video clip (0-based).</param>
    private void SetMaterialAndVideo(int index)
    {
        if (index < 0 || index >= materials.Length || index >= videoClips.Length)
        {
            Debug.LogError($"MaterialManager: Invalid index {index}. Ensure it is between 0 and 5.");
            return;
        }

        // Set the terrain's material
        terrainRenderer.material = materials[index];

        // Set the video clip for the VideoPlayer and play it
        textureVideo.clip = videoClips[index];

        Debug.Log($"MaterialManager: Material and video set for index {index}.");
    }
}
